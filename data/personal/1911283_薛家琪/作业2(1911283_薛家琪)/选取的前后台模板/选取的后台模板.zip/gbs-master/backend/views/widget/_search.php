<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use dosamigos\datepicker\DatePicker;
?>

<div class="col-lg-6" style="margin-top: 10px">
    <a href="/form-data">点击这里查看</a>
</div>
